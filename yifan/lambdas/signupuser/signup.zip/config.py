host="tasktrigger-test1.cf9tmf4lzflz.us-east-1.rds.amazonaws.com"
username="yyfyifan"
password="1992590"
database="db1"
port=3306