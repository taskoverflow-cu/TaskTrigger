import pymysql.cursors
from config import *
import random
# Connect to the database
connection = pymysql.connect(host= host,
                             user=username,
                             password=password,
                             db=database,
                             charset='utf8mb4',
                             cursorclass=pymysql.cursors.DictCursor)

# if the user does not exists
# with connection.cursor() as cursor:
#     sql = "SELECT * FROM `User`"
#     cursor.execute(sql)
#     result = cursor.fetchall()
#     for row in result:
#         print(row['username'], row['email'])

with connection.cursor() as cursor:
    cursor.execute("INSERT INTO User(username, email) VALUES('yyfyifan', %s)", (str(random.randint(10000,99999)) + '@qq.com' ) )

connection.commit()