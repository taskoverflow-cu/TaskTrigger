rds_host  = "tasktrigger-test1.cf9tmf4lzflz.us-east-1.rds.amazonaws.com"
name = 'master1'
password = '223092870'
db_name = 'db1'
es_host = "https://vpc-tasktrigger-domain-bmmm3cd2xeh4x3iex5aug35u3q.us-east-1.es.amazonaws.com"
es_port = 443